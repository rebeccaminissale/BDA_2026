import streamlit as st
import pandas as pd
import plotly.express as px

# DATA LOADING

st.set_page_config(page_title="Financial Transactions Dashboard", layout="wide")

@st.cache_data
def load_data():
    df = pd.read_csv("dashboard_data.csv")
    df['Date'] = pd.to_datetime(df['Date'])
    return df

df = load_data()

# SIDEBAR NAVIGATION

st.sidebar.title("Navigation")

page = st.sidebar.radio("Go to:", ["Page 1 - Time Analysis"])

# PAGE 1: TIME ANALYSIS (UPGRADED UI)

if page == "Page 1 - Time Analysis":
    st.title("Time Analysis Dashboard")
    st.markdown("Analyze financial transaction volumes and trends over time.")
    st.divider() 
    
    min_date = pd.to_datetime("2024-01-01").date()
    max_date = pd.to_datetime("2024-12-31").date()
    
    date_selection = st.sidebar.slider(
        "Select Date Range",
        min_value=min_date,
        max_value=max_date,
        value=(min_date, max_date)
    )
    
    start_date, end_date = date_selection
    mask = (df['Date'].dt.date >= start_date) & (df['Date'].dt.date <= end_date)
    filtered_df = df.loc[mask]
    
    if filtered_df.empty:
        st.warning("No transactions found for the selected date range.")
    else:
        total_transactions = len(filtered_df)
        total_units = filtered_df['Unit'].sum()
        top_symbol_overall = filtered_df['Symbol'].mode().iloc[0] 
        
        m1, m2, m3 = st.columns(3)
        m1.metric(label="Total Transactions", value=f"{total_transactions:,}")
        m2.metric(label="Total Units Traded", value=f"{total_units:,}")
        m3.metric(label="Most Traded Symbol", value=top_symbol_overall)
        st.divider()

        # CHART 1: Line chart 
        daily_tx = filtered_df.groupby('Date')['IDTransaction'].count().reset_index()
        fig_line = px.line(
            daily_tx, x='Date', y='IDTransaction', 
            title="Total Number of Transactions Over Time",
            template="plotly_white", 
            color_discrete_sequence=['#1f77b4'] 
        )
     
        fig_line.update_layout(xaxis_title="", yaxis_title="Number of Transactions", hovermode="x unified")
        st.plotly_chart(fig_line, use_container_width=True)
        
        # Create columns for side-by-side bar charts
        col1, col2, col3 = st.columns(3)
        
        with col1:
            # CHART 2: Top 3 Traded Symbols (Symbol and Company Name)
            top_symbols = filtered_df.groupby(['Symbol', 'Company_Name'])['IDTransaction'].count().reset_index().nlargest(3, 'IDTransaction')
            top_symbols['Display_Label'] = top_symbols['Symbol'] + " - " + top_symbols['Company_Name']
            
            top_symbols = top_symbols.sort_values(by='IDTransaction', ascending=True)
            
            fig_sym = px.bar(
                top_symbols, 
                x='IDTransaction', 
                y='Display_Label', 
                orientation='h',  
                title="Top 3 Traded Symbols", 
                template="plotly_white",
                color='Display_Label' 
            )
            fig_sym.update_layout(showlegend=False, xaxis_title="", yaxis_title="")
            st.plotly_chart(fig_sym, use_container_width=True)
            
        with col2:
            # CHART 3: Top 5 Sectors
            top_sectors = filtered_df.groupby('Sector')['IDTransaction'].count().reset_index().nlargest(5, 'IDTransaction')

            top_sectors = top_sectors.sort_values(by='IDTransaction', ascending=True)
            fig_sec = px.bar(
                top_sectors, x='IDTransaction', y='Sector', 
                orientation='h',
                title="Top 5 Sectors", 
                template="plotly_white",
                color_discrete_sequence=['#ff7f0e']
            )
            fig_sec.update_layout(xaxis_title="", yaxis_title="")
            st.plotly_chart(fig_sec, use_container_width=True)
            
        with col3:
            # CHART 4: Top 5 Industries
            top_industries = filtered_df.groupby('Industry')['IDTransaction'].count().reset_index().nlargest(5, 'IDTransaction')
            top_industries = top_industries.sort_values(by='IDTransaction', ascending=True)
            fig_ind = px.bar(
                top_industries, x='IDTransaction', y='Industry', 
                orientation='h',
                title="Top 5 Industries", 
                template="plotly_white",
                color_discrete_sequence=['#2ca02c']
            )
            fig_ind.update_layout(xaxis_title="", yaxis_title="")
            st.plotly_chart(fig_ind, use_container_width=True)


